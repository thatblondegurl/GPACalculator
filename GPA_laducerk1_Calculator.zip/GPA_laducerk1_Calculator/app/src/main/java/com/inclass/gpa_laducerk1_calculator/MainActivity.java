package com.inclass.gpa_laducerk1_calculator;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
// declrations of each input for each grade and button
public class MainActivity extends AppCompatActivity {
    private EditText input1;
    private EditText input2;
    private EditText input3;
    private EditText input4;
    private EditText input5;

    private TextView CumulativeGPA;

    private View parentView;

    private Button calculateButton;

    private boolean isCalculated;
    private double averageGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input1 = findViewById(R.id.first_editText);
        input2 = findViewById(R.id.second_editText);
        input3 = findViewById(R.id.third_editText);
        input4 = findViewById(R.id.fourth_editText);
        input5 = findViewById(R.id.fifth_editText);
        CumulativeGPA = findViewById(R.id.gpa_textView);
        parentView = findViewById(R.id.parent);

        CumulativeGPA.setText("0");
        calculateButton = findViewById(R.id.calculate_button);
        clearFields();
        //on click of calculation button gpa will calculate cummulative GPA
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isCalculated){
                    if(!isClear()){
                        double grade = 0;
                        grade += Integer.parseInt(input1.getText().toString().trim());
                        grade += Integer.parseInt(input2.getText().toString().trim());
                        grade += Integer.parseInt(input3.getText().toString().trim());
                        grade += Integer.parseInt(input4.getText().toString().trim());
                        grade += Integer.parseInt(input5.getText().toString().trim());
                        //adding the numbers
                        //getting the average
                        averageGrade = grade/5.0;
                        String text = String.format("%.2f",averageGrade);
                        CumulativeGPA.setText(text);
                        setBackGroundColor(averageGrade);
                        calculateButton.setText("Clear");
                        isCalculated = true;
                    }else{
                        //if any of the fields is empty it will tell the user an input is missing
                        Toast.makeText(MainActivity.this, "Please enter a grade", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    //clearing the fields
                    clearFields();
                    parentView.setBackgroundColor(getColor(R.color.white));
                    CumulativeGPA.setText("0");
                    calculateButton.setText("Compute GPA");
                    isCalculated = false;
                }
            }
        });
    }
//background colors that will show  if less than 60 red 61-80 yellow, 80-100 green and main color white
    private void setBackGroundColor(double grade) {
        //setting the color according to the grade
        if (grade<60){
            parentView.setBackgroundColor(getColor(R.color.red));
        }else if(grade>=60 && grade < 80){
            parentView.setBackgroundColor(getColor(R.color.yellow));
        }else if(grade>=80 && grade <= 100){
            parentView.setBackgroundColor(getColor(R.color.green));
        }else{
            //defaultColor
            parentView.setBackgroundColor(getColor(R.color.white));
        }
    }

    private boolean isClear() {
        //returns if any of the editTexts is empty or not
        return input1.getText().toString().trim().equals("")||input2.getText().toString().trim().equals("")||
                input3.getText().toString().trim().equals("")||input4.getText().toString().trim().equals("")||
                input5.getText().toString().trim().equals("");
    }

    private void clearFields() {
        //method to clear the editText views
        input1.setText("");
        input2.setText("");
        input3.setText("");
        input4.setText("");
        input5.setText("");
    }
}